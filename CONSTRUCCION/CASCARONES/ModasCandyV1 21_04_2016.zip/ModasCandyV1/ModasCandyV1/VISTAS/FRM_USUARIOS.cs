﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;
namespace ModasCandyV1
{
    public partial class FRM_USUARIOS : Form
    {
        public FRM_USUARIOS()
        {
            InitializeComponent();
        }

        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALESVARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES 
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALESVARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES 

        private Objeto_Usuario OBJ_USUARIO = new Objeto_Usuario();
        private String ACCION=null;
        
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALESVARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES 
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALESVARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES 
       
        //FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES
        //FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES

        // CARGA VALORES DE CAJAS DE TEXTO Y LAS AGREGA A LAS VARIABLES DEL OBJETO.
        public void CARGAR_OBJETO_ACTUAL()
        {
            OBJ_USUARIO.US_ID1         = int.Parse(TXT_ID_USUARIO.Text);
            OBJ_USUARIO.US_NOMBRE1     = TXT_NOMBRE_USUARIO.Text;
            OBJ_USUARIO.US_AP_PATERNO1 = TXT_AP_PATERMO_USUARIO.Text;
            OBJ_USUARIO.US_AP_MATERNO1 = TXT_AP_MATERNO_USUARIO.Text;
            OBJ_USUARIO.US_CONTRA1     = TXT_CONTRA_USUARIO.Text;
            OBJ_USUARIO.US_TIPO1 = short.Parse(TXT_NIVEL_USUARIO.Text);
        }

        // LIMPIA CAJAS DE TEXTO PARA REALIZAR INSERT
        public void LIMPIAR_CAMPOS()
        {

            TXT_ID_USUARIO.Text         = "0";
            TXT_NOMBRE_USUARIO.Text     = "";
            TXT_AP_PATERMO_USUARIO.Text = "";
            TXT_AP_MATERNO_USUARIO.Text = "";
            TXT_CONTRA_USUARIO.Text     = "";
            TXT_NIVEL_USUARIO.Text      = "0";

        }

        // MUESTRA EN CAJAS DE TEXTO EL REGISTRO ACTUAL SELECCIONADO EN EL DATA GRID
        public void CARGAR_DETALLE()
        {
            if (DATA_GRID_USUARIOS.RowCount > 0)
            {
                TXT_ID_USUARIO.Text          = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[0].Value.ToString();
                TXT_NOMBRE_USUARIO.Text      = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[1].Value.ToString();
                TXT_AP_PATERMO_USUARIO.Text  = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[2].Value.ToString();
                TXT_AP_MATERNO_USUARIO.Text  = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[3].Value.ToString();
                TXT_CONTRA_USUARIO.Text      = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[4].Value.ToString();
                TXT_NIVEL_USUARIO.Text       = DATA_GRID_USUARIOS.Rows[(DATA_GRID_USUARIOS.CurrentRow.Index)].Cells[5].Value.ToString();
            }
        }

        // MUESTRA EN CAJAS DE TEXTO LOS VALORES ACTUALES DE VARIABLES DE OBJETO.
        public void MOSTRAR_OBJETO_ACTUAL()
        {
            TXT_ID_USUARIO.Text         = OBJ_USUARIO.US_ID1.ToString();
            TXT_NOMBRE_USUARIO.Text     = OBJ_USUARIO.US_NOMBRE1.ToString();
            TXT_AP_PATERMO_USUARIO.Text = OBJ_USUARIO.US_AP_PATERNO1.ToString();
            TXT_AP_MATERNO_USUARIO.Text = OBJ_USUARIO.US_AP_MATERNO1.ToString();
            TXT_CONTRA_USUARIO.Text     = OBJ_USUARIO.US_CONTRA1.ToString();
            TXT_NIVEL_USUARIO.Text      = OBJ_USUARIO.US_TIPO1.ToString();
        }

        //CREA EL AMBIENTE PARA LA REALIZACION DE UNA ACCION...INSERT,UPDATE, DELETE,SELECT
        public void TRANSACCION_PROGRESO()
        {

            TXT_ID_USUARIO.Enabled         = false;
            TXT_NOMBRE_USUARIO.Enabled     = true;
            TXT_AP_PATERMO_USUARIO.Enabled = true;
            TXT_AP_MATERNO_USUARIO.Enabled = true;
            TXT_CONTRA_USUARIO.Enabled     = true;
            TXT_NIVEL_USUARIO.Enabled      = true;

            BTN_SEL_USUARIO.Enabled    = false;
            BTN_UPDT_USUARIO.Enabled   = false;
            BTN_DEL_USUARIO.Enabled    = false;
            BTN_INSERT_USUARIO.Enabled = false;

            BTN_ACEPTAR.Enabled = true;

        }
        //RECUPERA AMBIENTE DE TRABAJO DESPUES DE UNA TRANSACCION ..... INSERT, DELETE, UPDATE, SELECT
        public void TRANSACCION_FIN()
        {

            TXT_ID_USUARIO.Enabled         = false;
            TXT_NOMBRE_USUARIO.Enabled     = false;
            TXT_AP_PATERMO_USUARIO.Enabled = false;
            TXT_AP_MATERNO_USUARIO.Enabled = false;
            TXT_CONTRA_USUARIO.Enabled     = false;
            TXT_NIVEL_USUARIO.Enabled      = false;

            BTN_SEL_USUARIO.Enabled    = true;
            BTN_UPDT_USUARIO.Enabled   = true;
            BTN_DEL_USUARIO.Enabled    = true;
            BTN_INSERT_USUARIO.Enabled = true;

            BTN_ACEPTAR.Enabled = false;

        }


        //FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES
        //FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES FUNCIONES



        ///ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES
        ///ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES
        

        //FUNCION DE PRUEBA PARA CREAR BASE DE DATOS DESDE EL SISTEMA NO TOMAR EN CUENTA
        private void BTN_CREAR_BASE_Click(object sender, EventArgs e)
        {
            SqlCeEngine CON =new SqlCeEngine("DataSource=\"BASE_MODAS_CANDY_V1.sdf\";Password=\"123\"");
            CON.CreateDatabase();

        }

        //FUNCION DE PRUEBA PARA CREAR TABLAS DESDE EL SISTEMA NO TOMAR EN CUENTA
        private void BTN_CREAR_TABLE_Click(object sender, EventArgs e)
        {

            SqlCeConnection CONX = new SqlCeConnection("DataSource=\"BASE_MODAS_CANDY_V1.sdf\";Password=\"123\"");
            SqlCeCommand COMD;  
            CONX.Open();
            
            COMD = new SqlCeCommand(@"
                                     create table USUARIO
                                    (
                                     US_ID          int          PRIMARY KEY NOT NULL,
                                     US_NOMBRE      NVARCHAR(50) NOT NULL,
                                     US_AP_PATERNO  NVARCHAR(50) NOT NULL,
                                     US_AP_MATERNO  NVARCHAR(50)     NULL,
                                     US_CONTRA      NVARCHAR(20) NOT NULL,
                                     US_TIPO        int          NOT NULL
                                    )", CONX);

            COMD.ExecuteNonQuery();

            CONX.Close();
        }

        /// AL ABRIR LA PANTALLA USUARIOS LLENA EL DATA_GRID CON LA INFORMACION DE TODOS LOS USUSARIOS EN BASE DE DATOS
        private void FRM_USUARIOS_Load(object sender, EventArgs e)
        {
            // CARGA DATA GRID CON DATOS DE USUARIO
            DATA_GRID_USUARIOS.DataSource = OBJ_USUARIO.Seleccionar_Usuario(false);
            //MUESTRA REGISTRO SELECCIONADO EN CAMPOS DE TEXTO
            CARGAR_DETALLE();
            // CARGA CONFIGURACION DE TABLA DE REGISTRO
            OBJ_USUARIO.CONF_DE_VARIABLES();
            // CARGA CONFIGURACION DE COMBOBOX
            CMB_FILTRO_USUARIO.DataSource = OBJ_USUARIO.TBL_FILTRO1;
            CMB_FILTRO_USUARIO.DisplayMember = "ALIAS";
            CMB_FILTRO_USUARIO.ValueMember = "CAMPO";
        }

        //ACCION DE BOTON INSERTAR, EL CUAL CREA EL AMBIENTE NECESARIO PARA COMENSAR A INSERTAR UN USUARIO
        private void BTN_INSERT_USUARIO_Click(object sender, EventArgs e)
        {
            TRANSACCION_PROGRESO();
            LIMPIAR_CAMPOS();
            TXT_ID_USUARIO.Text= OBJ_USUARIO.Seleccionar_MAX().ToString();
            ACCION = "INSERT";

        }
        //ACCION DEL BOTON ACTUALIZAR, EL CUAL CREA EL AMBIENTE NECESARIO PARA ACTUALIZAR UN USUARIO 
        private void BTN_UPDT_USUARIO_Click(object sender, EventArgs e)
        {
            TRANSACCION_PROGRESO();
            CARGAR_OBJETO_ACTUAL();
            ACCION= "UPDATE";
        }
        //ACCION DEL BOTON BORRADO, EL CUEL CREA EL AMBIENTE NECESARIO PARA BORRAR UN USUARIO
        private void BTN_DEL_USUARIO_Click(object sender, EventArgs e)
        {
            TRANSACCION_PROGRESO();
            ACCION = "DELETE";
        }
        //ACCION DEL BOTON ACEPTAR, REALIZA LA ACCION EN PROCESO.
        private void BTN_ACEPTAR_Click_1(object sender, EventArgs e)
        {
            CARGAR_OBJETO_ACTUAL();

            if (ACCION.Equals("INSERT"))
            {
                OBJ_USUARIO.insertar_usuario();
            }
            if (ACCION.Equals("UPDATE"))
            {
                OBJ_USUARIO.Actualizar_usuario();
            }
            if (ACCION.Equals("DELETE"))
            {
                OBJ_USUARIO.Eliminar_Usuario();
            }
            if (ACCION.Equals("SELECT"))
            {
                OBJ_USUARIO.Seleccionar_Usuario(false);
            }


            TRANSACCION_FIN();
            DATA_GRID_USUARIOS.DataSource = OBJ_USUARIO.Seleccionar_Usuario(false);
            CARGAR_DETALLE();

            MessageBox.Show("accion realizada");

        }

        // AL DAR CLIC EN ALGUN REGISTRO DEL DATA GRID SE CAMBIA DE PANTALLA Y SE MUESTRA EL REGISTRO EN LAS CAJAS DE TEXTO
        private void DATA_GRID_USUARIOS_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CARGAR_DETALLE();
            TAB_PRINCIPAL.SelectedIndex = 1;
        }

        // AL INGRESAR UN VALOR EN EL FILTRO SE CAMBIA AUTOMATICAMENTE EL DATA GRID
        private void TXT_FILTRO_USUARIO_TextChanged(object sender, EventArgs e)
        {
            OBJ_USUARIO.TBL_FILTRO_VALOR_AGREGAR(CMB_FILTRO_USUARIO.SelectedValue.ToString(), true,TXT_FILTRO_USUARIO.Text);

            DATA_GRID_USUARIOS.DataSource = OBJ_USUARIO.Seleccionar_Usuario(true);
        }




        ///ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES
        ///ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES ACCIONES
        
    }
}
