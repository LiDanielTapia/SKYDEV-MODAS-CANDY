﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;
using System.Data;

namespace ModasCandyV1
{
    class Objeto_Conexion
    {
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES
        
        private string _c = "DataSource=\"BASE_MODAS_CANDY_V1.sdf\";Password=\"123\"";
        private SqlCeCommand _cmd;
        private SqlCeConnection _con;
        private SqlCeDataAdapter _da;
        private SqlCeTransaction _tr;
        
        private Herramientas tool = new Herramientas();
        String comando = null;
        
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES
        //VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES VARIABLES LOCALES

        // ABRE CONEXION A BASE DE DATOS
        public void Open_Conexcion ()
        {
            _con = new SqlCeConnection(_c);
            _con.Open();
            _tr = _con.BeginTransaction();
        }
        //EJECUTA TRANSACCION QUE NO NECESITA REGRESO DE DATOS (INSERT,DELETE,UPDATE)
        // ACCION: QUE ACCION DESEAS HACER : "INSERT" , "DELETE", "UPDATE"
        // TABLA: NOMBRE DE LA TABLA DONDE SE EJECUTARA LA ACCION : "USUARIO"
        // PARAMETROS: CAMPOS CON SUS VALORES NECESARIOS PARA LA ACCION : USUARIO ACTUAL.(get_table_usuario_actual)
        public void Ejecutar_Transaccion(String accion,String tabla,DataTable parametros)
        {
            comando = null;

            if (accion.Equals("INSERT"))
            {
                comando = "INSERT INTO " + tabla.ToString() + " values ( ";

                for (int j = 0; parametros.Columns.Count-1 > j; j++)
                {
                    comando += tool.agregar_comillas(parametros.Rows[0][j]) + " ,";
                }
                comando += tool.agregar_comillas(parametros.Rows[0][parametros.Columns.Count - 1]) + ") ";
            }

            if (accion.Equals("UPDATE"))
            {
                comando = "UPDATE " + tabla.ToString() + " SET " ;

                for (int j = 1; parametros.Columns.Count - 1 > j; j++)
                {
                    comando += parametros.Columns[j].ColumnName.ToString() + " = "+tool.agregar_comillas(parametros.Rows[0][j])+" ,";
                }
                comando += parametros.Columns[parametros.Columns.Count - 1].ColumnName.ToString() + " = "+tool.agregar_comillas(parametros.Rows[0][parametros.Columns.Count - 1]);                        
                comando += " WHERE " +parametros.Columns[0].ColumnName+"=" + tool.agregar_comillas(parametros.Rows[0][0]);

            }

            if (accion.Equals("DELETE"))
            {
                comando = "DELETE " + tabla.ToString();
                comando += " WHERE " + parametros.Columns[0].ColumnName + "=" + tool.agregar_comillas(parametros.Rows[0][0]);
            }

            _cmd = new SqlCeCommand(@"" + comando.ToString(), _con);           
            _cmd.Connection = _con;
            _cmd.Transaction = _tr;
            _cmd.ExecuteNonQuery();
        }
         //FUNCION PARA SELECCIONAR REGISTROS, EN TRES MODALIDADES
        // 1.- SELECT * FROM TABLA
        // 2.- SELECT CAMPOS.... FROM TABLA
        // 3.- SELECT CAMPOS.... FROM TABLA WHERE VALORES.......
        //
        // TABLA             : NOMBRE DE LA TABLA DONDE SE EJECUTARA LA ACCION: "USUARIO"
        // FILTRO_CAMPO      : BANDERA INDICADORA DE RECUPERACION DE VALORES DE CAMPOS ESPESIFICOS :SELECT US_ID,US_NOMBRE.... FROM USUARIO
        // FILTRO_VALOR      : BANDERA INDICADORE DE RECUPERACION DE VALORES DE CONDICION ESPEFICIA: SELEC ..FROM WHERE US_ID =2 AND US_NOMBRE="PEDRO"
        // TBL_FILTRO_CAMPOS : TABLA DE FILTRO LA CUAL CONTIENE LOS CAMPOS Y VALORES QUE SE TOMARAN EN CUENTA PARA EL SELECT.
        public DataTable Select_Transaccion(String TABLA,Boolean FILTO_CAMPO,Boolean FILTRO_CONDICION,DataTable TBL_FILTRO_CAMPOS) {

            DataTable resultado=null;
            String comando = null;
            bool primero=false;

            if (!FILTO_CAMPO)
            {
                comando = "SELECT  * from " + TABLA.ToString(); 
            } else{
                comando = "SELECT ";
                if (TBL_FILTRO_CAMPOS.Rows[0][3].Equals(true))
                {
                    comando += TBL_FILTRO_CAMPOS.Rows[TBL_FILTRO_CAMPOS.Rows.Count - 1][0] + " ";
                    primero = true;
                }
                for (int i = 1; TBL_FILTRO_CAMPOS.Rows.Count > i; i++)
                {
                    if(TBL_FILTRO_CAMPOS.Rows[i][3].Equals(true) && primero){
                          comando +=" , " + TBL_FILTRO_CAMPOS.Rows[i][0];
                    }
                    if (TBL_FILTRO_CAMPOS.Rows[i][3].Equals(true) && !primero)
                    {
                        comando += " "+ TBL_FILTRO_CAMPOS.Rows[i][0];
                        primero = true;
                    }
                }
                comando += " FROM " + TABLA.ToString();
            }
            if (FILTRO_CONDICION)
            {
                comando += " WHERE ";
                if (TBL_FILTRO_CAMPOS.Rows[0][4].Equals(true))
                {
                    comando += TBL_FILTRO_CAMPOS.Rows[0][0].ToString() + " LIKE '%" + TBL_FILTRO_CAMPOS.Rows[0][2]+ "%'";
                    primero = true;
                }
                for (int i = 1; TBL_FILTRO_CAMPOS.Rows.Count> i; i++)
                {
                    if (TBL_FILTRO_CAMPOS.Rows[i][4].Equals(true) && primero)
                    {
                        comando += " AND " + TBL_FILTRO_CAMPOS.Rows[i][0].ToString() + " LIKE  '%" + TBL_FILTRO_CAMPOS.Rows[i][2]+"%'";
                        primero = true;
                    }
                    if (TBL_FILTRO_CAMPOS.Rows[i][4].Equals(true) && !primero)
                    {
                        comando += " " + TBL_FILTRO_CAMPOS.Rows[i][0].ToString() + " LIKE  '%" + TBL_FILTRO_CAMPOS.Rows[i][2] + "%'";
                        primero = true;
                    }
                }
            }

            _cmd = new SqlCeCommand(@"" + comando.ToString(), _con);                               
            _da = new SqlCeDataAdapter(_cmd);
            resultado = new DataTable();
            _da.Fill(resultado);
            _cmd.ExecuteReader();
           
            return resultado;
        }

        //FUNCION PARA RECUPERAR EL ID DE TABLA
        // TABLA: NOMBRE DE TABLA : "USUARIOS"
        // ID: CAMPO A RECUPERAR MAXIMO : "US_ID"
        public int select_max(string tabla , string id) {

            DataTable resultado = new DataTable();
            string max = null;
            _cmd = new SqlCeCommand(@"SELECT MAX("+id+") FROM " +tabla , _con);
            _da = new SqlCeDataAdapter(_cmd);
            resultado = new DataTable();
            _da.Fill(resultado);
            _cmd.ExecuteReader();

            max = resultado.Rows[0][0].ToString();
            if (max.Equals("")) {max = "0"; }

            return int.Parse(max);
        }
        // ACEPTAR TRANSACCION 
        public void Comit_Transaccion()
        {
            _tr.Commit();
            _con.Close();
        }
        // REGRESAR TRANSACCION
        public void Rolback_Transaccion()
        {
            _tr.Rollback();
            _con.Close();
        }
      


    }
}
