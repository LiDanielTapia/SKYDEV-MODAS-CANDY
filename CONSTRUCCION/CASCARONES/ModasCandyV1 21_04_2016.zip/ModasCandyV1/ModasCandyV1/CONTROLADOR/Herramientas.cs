﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModasCandyV1
{
    class Herramientas
    {

        public String agregar_comillas(object dato)
        {
            String retorno = null;

            


            if (dato.GetType().ToString().Equals("System.Int32"))
            {

                retorno += int.Parse(dato.ToString());

            }
            if (dato.GetType().ToString().Equals("System.String"))
            {
                int IS_NUM;

                bool NUM = int.TryParse(dato.ToString(), out  IS_NUM);

                if (NUM)
                {
                    retorno += IS_NUM;
                }
                else {
                    retorno += "'" + dato.ToString() + "'";
                
                }
            }





            return retorno;
        }


        public string CAMBIAR_FECHA_SQL(DateTime FECHA_CSHARP){
        
            string STRFECHA=null;
            STRFECHA = " Convert (DateTime,'" + FECHA_CSHARP.ToString("yyyyMMdd") + "',112) ";
        
            return STRFECHA;
        }
    }
}
