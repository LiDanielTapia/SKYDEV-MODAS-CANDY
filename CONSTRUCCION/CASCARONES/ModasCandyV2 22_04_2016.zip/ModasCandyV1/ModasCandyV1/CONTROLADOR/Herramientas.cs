﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;


namespace ModasCandyV1
{
    class Herramientas
    {

        public String agregar_comillas(object dato)
        {
            String retorno = null;

            


            if (dato.GetType().ToString().Equals("System.Int32"))
            {

                retorno += int.Parse(dato.ToString());

            }
            if (dato.GetType().ToString().Equals("System.String"))
            {
                int IS_NUM;

                bool NUM = int.TryParse(dato.ToString(), out  IS_NUM);

                if (NUM)
                {
                    retorno += IS_NUM;
                }
                else {
                    retorno += "'" + dato.ToString() + "'";
                
                }
            }





            return retorno;
        }


        public System.IO.MemoryStream CONVERTIR_IMAGENES_SQL(PictureBox image)
        {

            System.IO.MemoryStream ms = new System.IO.MemoryStream();

            image.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);

           // return ms.GetBuffer();
            return ms;
        }

        public void CONVERTIR_SQL_IMAGEN( PictureBox imagen, byte[] IMGAGE)
        {
            PictureBox RETORNO = new PictureBox();

            System.IO.MemoryStream ms = new System.IO.MemoryStream(IMGAGE);

            imagen.Image = System.Drawing.Bitmap.FromStream(ms);

              
        }



        public string CAMBIAR_FECHA_SQL(DateTime FECHA_CSHARP){
        
            string STRFECHA=null;
            STRFECHA = " Convert (DateTime,'" + FECHA_CSHARP.ToString("yyyyMMdd") + "',112) ";
        
            return STRFECHA;
        }
    }
}
