﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace ModasCandyV1
{
    public class Objeto_Usuario
    {

        //INSTANCIA DE CONEXION DE BASE DE DATOS 
        private Objeto_Conexion con = new Objeto_Conexion();

        //INICIO VARIABLES DE TABLA
        private string TBL_USUARIO = "USUARIO";
        private int US_ID = 0;
        private String US_NOMBRE = null;
        private String US_AP_PATERNO = null;
        private String US_AP_MATERNO = null;
        private String US_CONTRA = null;
        private int US_TIPO = 0;
        private PictureBox US_IMAGE = new PictureBox();

        //VARIABLES LOCALES
        private DataTable TBL_USUARIOS = new DataTable();
        private DataTable TBL_FILTRO = new DataTable();

        //FUNCION QUE DEBUELBE EN FORMA DE TABLA LOS VALORES DE CAMPOS DE LA TABLA 
        public DataTable get_table_usuario_actual()
        {

            DataTable actual_usuario = new DataTable();

            actual_usuario.Columns.Add("US_ID", typeof(int));
            actual_usuario.Columns.Add("US_NOMBRE", typeof(String));
            actual_usuario.Columns.Add("US_AP_PATERNO", typeof(String));
            actual_usuario.Columns.Add("US_AP_MATERNO", typeof(String));
            actual_usuario.Columns.Add("US_CONTRA", typeof(String));
            actual_usuario.Columns.Add("US_TIPO", typeof(int));
            actual_usuario.Columns.Add("US_IMAGE", typeof(PictureBox));

         
            actual_usuario.Rows.Add(US_ID1,
                                 US_NOMBRE1,
                                 US_AP_PATERNO1,
                                 US_AP_MATERNO1,
                                 US_CONTRA1,
                                 US_TIPO1,
                                 US_IMAGE1
                                 );

            return actual_usuario;
        }

        public void CONF_DE_VARIABLES()
        {
            //CONFIGURACION DE TABLA DE FILTROS POR CAMPO Y VALOR.
            
            TBL_FILTRO1.Columns.Add("CAMPO"       , typeof(String)  );
            TBL_FILTRO1.Columns.Add("ALIAS"       , typeof(String)  );
            TBL_FILTRO1.Columns.Add("VALOR"       , typeof(string)  );
            TBL_FILTRO1.Columns.Add("FILTRO_CAMPO", typeof(Boolean) );
            TBL_FILTRO1.Columns.Add("FILTRO_VALOR", typeof(Boolean) );

            TBL_FILTRO1.Rows.Add("US_ID"          , "ID USUARIO"      , US_ID1         , false, false);
            TBL_FILTRO1.Rows.Add("US_NOMBRE"      , "NOMBRE "         , US_NOMBRE1     , false, false);
            TBL_FILTRO1.Rows.Add("US_AP_PATERNO"  , "APELLIDO PATERNO", US_AP_PATERNO1 , false, false);
            TBL_FILTRO1.Rows.Add("US_AP_MATERNO"  , "APELLIDO MATERNO", US_AP_MATERNO1 , false, false);
            //TBL_FILTRO1.Rows.Add("US_CONTRA"    , "CONTRASEÑA"      , US_CONTRA1     , false, false);
            TBL_FILTRO1.Rows.Add("US_TIPO"        , "TIPO"            , US_TIPO1       , false, false);
            //TBL_FILTRO1.Rows.Add("US_IMAGE"     , "IMAGEN"          , US_IMAGE1      , false, false);
        }

        //CAMBIA TTRUE A CAMPO DE TABLA DE FILTRO PARA SER TOMADO EN UN SELECT CON FILTRO, BANDERA INDICA SI SE CAMBIAN TODOS LOS DEMAS CAMPOS A FALSE PARA SOLO TOMAR EN CUENTA EL CAMPO INGRESADO
        public void TBL_FILTRO_CAMPOS_AGREGAR(string AGREGAR, Boolean BORRAR_OTROS)
        {
            DataTable aux=new DataTable();

            if (BORRAR_OTROS){ TBL_FILTRO_CAMPOS_LIMPIAR();}

            for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                if (TBL_FILTRO1.Rows[i][0].Equals(AGREGAR.ToString()))
                {
                    TBL_FILTRO1.Rows[i][3] = true;
                }   
            }
        }

        // MARCA CON FALSE LOS CAMPOS QUE NO SE TOMARAN EN CUENTA EN UN SELEC CON FILTRO
        // QUITAR       : NOMBRE DE CAMPO QUE SE DESEA MARCAR DE TABLA DE FILTROS PARA NO SER TOMADO EN CUENTA EN SELECT CON FILTRO : "US_ID"
        // BORRAR_OTROS : BANDERA INDICADORA PARA MARCAR EN FALSE TODOS LOS CAMPOS DE TABLA DE FILTRO ANTES DE MARCAR LA ACTUAL: 
        public void TBL_FILTRO_CAMPOS_QUITAR(String QUITAR, Boolean BORRAR_OTROS)
        {
           for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                if (TBL_FILTRO1.Rows[i][1].Equals(QUITAR.ToString()))
                {
                    TBL_FILTRO1.Rows[i][3] = false;
                }
            }

        }

        //MARCA TODOS LOS CAMPOS CON FALSE DE LA TABLA DE FILTROS PARA NO SER CONSIDERADOS EN UN SELEC CON FILTRO
        public void TBL_FILTRO_CAMPOS_LIMPIAR()
        {
            for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                TBL_FILTRO1.Rows[i][3] = false;   
            }
        }

        // AGREGA UN VALOR Y CAMBIA LABANDERA DEL REGISTRO A TRUE PARA SER CONSIDERADO EN UN SELECT CON FILTRO
        // AGREGAR      : NOMBRE DE CAMPO QUE SE DESEA MARCAR COMO TRUE PARA SER CONSIDERADO EN UN SELECT CON FILTRO: "US_ID"
        // BORRAR_OTROS : BANDERA INDICADORA PARA MARCAR EN FALSE TODOS LOS CAMPOS DE TABLA DE FILTRO ANTES DE MARCAR LA ACTUAL: 
        // VALOR        : VALOR CON EL CUAL SE REALIZARA LA CONDIFION DE FILTRO: WHERE CAMPO= "VALOR"
        public void TBL_FILTRO_VALOR_AGREGAR(String AGREGAR, Boolean BORRAR_OTROS,String VALOR)
        {
            if (BORRAR_OTROS) { TBL_FILTRO_VALOR_LIMPIAR(); }

            for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                if (TBL_FILTRO1.Rows[i][0].Equals(AGREGAR.ToString()))
                {
                    TBL_FILTRO1.Rows[i][4] = true;
                    TBL_FILTRO1.Rows[i][2] = VALOR.ToString();
                }
            }
        }

        // COLOCA FALSE A UN CAMPO PARA NO SER CONSIDERADO EN UN SELECT CON FILTRO
        // QUITAR       : NOMBRE DE CAMPO QUE SE MARCA COMO FALSE Y NO SE TOMA EN CUENTA SU VALOR EN UN SELECT CON FILTRO.
        // BORRAR_OTROS : MARCA CON FALSE TODOS LOS CAMPOS DE LA TABLA FILTRO PARA QUE NO SEAN TOMADOS EN CUENTA EN UN SELECT CON FILTRO.
        public void TBL_FILTRO_VALOR_QUITAR(String QUITAR, Boolean BORRAR_OTROS)
        {
  
            for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                if (TBL_FILTRO1.Rows[i][1].Equals(QUITAR.ToString()))
                {
                    TBL_FILTRO1.Rows[i][4] = false;
                }
            }

        }
        //LIMPIA BANDERAS DE TABLA DE FILTRO PARA NO SER CONSIDERADOS EN UN SELECT CON FILTRO
        public void TBL_FILTRO_VALOR_LIMPIAR()
        {
            for (int i = 0; TBL_FILTRO1.Rows.Count > i; i++)
            {
                TBL_FILTRO1.Rows[i][4] = false;
            }
        }
        

        // FUNCION QUE INSERTA USUARIOS... DEBES CARGAR ANTES LOS VALORES EN CAMPOS DE TABLA
        public Boolean insertar_usuario()
        {
            con.Open_Conexcion();
            con.Ejecutar_Transaccion("INSERT", TBL_USUARIO, get_table_usuario_actual());
            con.Comit_Transaccion();

            return true;
        }

        // FUNCION QUE ACTUALIZA USUARIOS... DEBES CARGAR ANTES LOS VALORES EN CAMPOS DE TABLA
        public Boolean Actualizar_usuario()
        {
            con.Open_Conexcion();
            con.Ejecutar_Transaccion("UPDATE", TBL_USUARIO, get_table_usuario_actual());
            con.Comit_Transaccion();

            return true;
        }

        // FUNCION QUE ELIMINA USUARIOS... DEBES CARGAR ANTES LOS VALORES EN CAMPOS DE TABLA
        public Boolean Eliminar_Usuario()
        {
            con.Open_Conexcion();
            con.Ejecutar_Transaccion("DELETE", TBL_USUARIO, get_table_usuario_actual());
            con.Comit_Transaccion();

            return true;
        }
        //SELECCIONA USUARIOS A PARTIR DE FILTRO O NO.
        public DataTable Seleccionar_Usuario(Boolean FILTRO)
        {
            DataTable RESP = new DataTable();
            con.Open_Conexcion();

            if (FILTRO)
            {
                RESP = con.Select_Transaccion(TBL_USUARIO, false, true, TBL_FILTRO1);
            }
            else
            {
                RESP = con.Select_Transaccion(TBL_USUARIO, false, false, TBL_FILTRO1);
            }
            con.Comit_Transaccion();

            return RESP;
        }
        //RECUPARA EL MAXIMO ID DE UNA TABLA
        public int Seleccionar_MAX()
        {
            int RESP = 0;
            con.Open_Conexcion();


            RESP = con.select_max(TBL_USUARIO, get_table_usuario_actual().Columns[0].ColumnName.ToString());

            con.Comit_Transaccion();

            return RESP + 1;
        }


        //ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA
        //ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA

        public int US_ID1
        {
            get { return US_ID; }
            set { US_ID = value; }
        }
        public String US_NOMBRE1
        {
            get { return US_NOMBRE; }
            set { US_NOMBRE = value; }
        }
        public String US_AP_PATERNO1
        {
            get { return US_AP_PATERNO; }
            set { US_AP_PATERNO = value; }
        }
        public String US_AP_MATERNO1
        {
            get { return US_AP_MATERNO; }
            set { US_AP_MATERNO = value; }
        }
        public String US_CONTRA1
        {
            get { return US_CONTRA; }
            set { US_CONTRA = value; }
        }
        public int US_TIPO1
        {
            get { return US_TIPO; }
            set { US_TIPO = value; }
        }
        public DataTable TBL_FILTRO1
        {
            get { return TBL_FILTRO; }
            set { TBL_FILTRO = value; }
        }

        public PictureBox US_IMAGE1
        {
            get { return US_IMAGE; }
            set { US_IMAGE = value; }
        }

        //ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA
        //ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA ENCAPSULACION DE CAMPOS DE TABLA

    }
}
