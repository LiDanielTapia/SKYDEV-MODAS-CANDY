﻿namespace ModasCandyV1
{
    partial class FRM_USUARIOS
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.TAB_PRINCIPAL = new System.Windows.Forms.TabControl();
            this.tab_tbl_usuario = new System.Windows.Forms.TabPage();
            this.DATA_GRID_USUARIOS = new System.Windows.Forms.DataGridView();
            this.tab_tbl_us_detale = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.TXT_AP_MATERNO_USUARIO = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TXT_AP_PATERMO_USUARIO = new System.Windows.Forms.TextBox();
            this.BTN_ACEPTAR = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_NOMBRE_USUARIO = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BTN_DEL_USUARIO = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.BTN_UPDT_USUARIO = new System.Windows.Forms.Button();
            this.TXT_NOMBRE_USUARIO = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TXT_ID_USUARIO = new System.Windows.Forms.TextBox();
            this.TXT_CONTRA_USUARIO = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BTN_INSERT_USUARIO = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TXT_NIVEL_USUARIO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BTN_CREAR_BASE = new System.Windows.Forms.Button();
            this.BTN_CREAR_TABLE = new System.Windows.Forms.Button();
            this.BTN_SEL_USUARIO = new System.Windows.Forms.Button();
            this.CMB_FILTRO_USUARIO = new System.Windows.Forms.ComboBox();
            this.TXT_FILTRO_USUARIO = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTN_ABRIR_IMAGE = new System.Windows.Forms.Button();
            this.TAB_PRINCIPAL.SuspendLayout();
            this.tab_tbl_usuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DATA_GRID_USUARIOS)).BeginInit();
            this.tab_tbl_us_detale.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // TAB_PRINCIPAL
            // 
            this.TAB_PRINCIPAL.Controls.Add(this.tab_tbl_usuario);
            this.TAB_PRINCIPAL.Controls.Add(this.tab_tbl_us_detale);
            this.TAB_PRINCIPAL.Location = new System.Drawing.Point(53, 57);
            this.TAB_PRINCIPAL.Name = "TAB_PRINCIPAL";
            this.TAB_PRINCIPAL.SelectedIndex = 0;
            this.TAB_PRINCIPAL.Size = new System.Drawing.Size(600, 310);
            this.TAB_PRINCIPAL.TabIndex = 16;
            // 
            // tab_tbl_usuario
            // 
            this.tab_tbl_usuario.Controls.Add(this.DATA_GRID_USUARIOS);
            this.tab_tbl_usuario.Location = new System.Drawing.Point(4, 22);
            this.tab_tbl_usuario.Name = "tab_tbl_usuario";
            this.tab_tbl_usuario.Padding = new System.Windows.Forms.Padding(3);
            this.tab_tbl_usuario.Size = new System.Drawing.Size(592, 284);
            this.tab_tbl_usuario.TabIndex = 0;
            this.tab_tbl_usuario.Text = "Uduarios";
            this.tab_tbl_usuario.UseVisualStyleBackColor = true;
            // 
            // DATA_GRID_USUARIOS
            // 
            this.DATA_GRID_USUARIOS.AllowUserToAddRows = false;
            this.DATA_GRID_USUARIOS.AllowUserToDeleteRows = false;
            this.DATA_GRID_USUARIOS.BackgroundColor = System.Drawing.SystemColors.Window;
            this.DATA_GRID_USUARIOS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATA_GRID_USUARIOS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DATA_GRID_USUARIOS.Location = new System.Drawing.Point(3, 3);
            this.DATA_GRID_USUARIOS.Name = "DATA_GRID_USUARIOS";
            this.DATA_GRID_USUARIOS.ReadOnly = true;
            this.DATA_GRID_USUARIOS.Size = new System.Drawing.Size(586, 278);
            this.DATA_GRID_USUARIOS.TabIndex = 0;
            this.DATA_GRID_USUARIOS.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_GRID_USUARIOS_CellClick);
            // 
            // tab_tbl_us_detale
            // 
            this.tab_tbl_us_detale.Controls.Add(this.BTN_ABRIR_IMAGE);
            this.tab_tbl_us_detale.Controls.Add(this.pictureBox1);
            this.tab_tbl_us_detale.Controls.Add(this.label10);
            this.tab_tbl_us_detale.Controls.Add(this.label11);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_AP_MATERNO_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label8);
            this.tab_tbl_us_detale.Controls.Add(this.label9);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_AP_PATERMO_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.BTN_ACEPTAR);
            this.tab_tbl_us_detale.Controls.Add(this.label1);
            this.tab_tbl_us_detale.Controls.Add(this.lbl_NOMBRE_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label2);
            this.tab_tbl_us_detale.Controls.Add(this.BTN_DEL_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label5);
            this.tab_tbl_us_detale.Controls.Add(this.BTN_UPDT_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_NOMBRE_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label7);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_ID_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_CONTRA_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label4);
            this.tab_tbl_us_detale.Controls.Add(this.BTN_INSERT_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label6);
            this.tab_tbl_us_detale.Controls.Add(this.TXT_NIVEL_USUARIO);
            this.tab_tbl_us_detale.Controls.Add(this.label3);
            this.tab_tbl_us_detale.Location = new System.Drawing.Point(4, 22);
            this.tab_tbl_us_detale.Name = "tab_tbl_us_detale";
            this.tab_tbl_us_detale.Padding = new System.Windows.Forms.Padding(3);
            this.tab_tbl_us_detale.Size = new System.Drawing.Size(592, 284);
            this.tab_tbl_us_detale.TabIndex = 1;
            this.tab_tbl_us_detale.Text = "Detalle";
            this.tab_tbl_us_detale.UseVisualStyleBackColor = true;
            this.tab_tbl_us_detale.Click += new System.EventHandler(this.tab_tbl_us_detale_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "NOMBRE:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "NOMBRE:";
            // 
            // TXT_AP_MATERNO_USUARIO
            // 
            this.TXT_AP_MATERNO_USUARIO.Enabled = false;
            this.TXT_AP_MATERNO_USUARIO.Location = new System.Drawing.Point(107, 112);
            this.TXT_AP_MATERNO_USUARIO.Name = "TXT_AP_MATERNO_USUARIO";
            this.TXT_AP_MATERNO_USUARIO.Size = new System.Drawing.Size(176, 20);
            this.TXT_AP_MATERNO_USUARIO.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "NOMBRE:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "NOMBRE:";
            // 
            // TXT_AP_PATERMO_USUARIO
            // 
            this.TXT_AP_PATERMO_USUARIO.Enabled = false;
            this.TXT_AP_PATERMO_USUARIO.Location = new System.Drawing.Point(107, 86);
            this.TXT_AP_PATERMO_USUARIO.Name = "TXT_AP_PATERMO_USUARIO";
            this.TXT_AP_PATERMO_USUARIO.Size = new System.Drawing.Size(176, 20);
            this.TXT_AP_PATERMO_USUARIO.TabIndex = 18;
            // 
            // BTN_ACEPTAR
            // 
            this.BTN_ACEPTAR.Location = new System.Drawing.Point(464, 132);
            this.BTN_ACEPTAR.Name = "BTN_ACEPTAR";
            this.BTN_ACEPTAR.Size = new System.Drawing.Size(101, 40);
            this.BTN_ACEPTAR.TabIndex = 15;
            this.BTN_ACEPTAR.Text = "ACEPTAR";
            this.BTN_ACEPTAR.UseVisualStyleBackColor = true;
            this.BTN_ACEPTAR.Click += new System.EventHandler(this.BTN_ACEPTAR_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID :";
            // 
            // lbl_NOMBRE_USUARIO
            // 
            this.lbl_NOMBRE_USUARIO.AutoSize = true;
            this.lbl_NOMBRE_USUARIO.Location = new System.Drawing.Point(24, 60);
            this.lbl_NOMBRE_USUARIO.Name = "lbl_NOMBRE_USUARIO";
            this.lbl_NOMBRE_USUARIO.Size = new System.Drawing.Size(57, 13);
            this.lbl_NOMBRE_USUARIO.TabIndex = 1;
            this.lbl_NOMBRE_USUARIO.Text = "NOMBRE:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID :";
            // 
            // BTN_DEL_USUARIO
            // 
            this.BTN_DEL_USUARIO.Location = new System.Drawing.Point(353, 234);
            this.BTN_DEL_USUARIO.Name = "BTN_DEL_USUARIO";
            this.BTN_DEL_USUARIO.Size = new System.Drawing.Size(84, 41);
            this.BTN_DEL_USUARIO.TabIndex = 14;
            this.BTN_DEL_USUARIO.Text = "BORRAR";
            this.BTN_DEL_USUARIO.UseVisualStyleBackColor = true;
            this.BTN_DEL_USUARIO.Click += new System.EventHandler(this.BTN_DEL_USUARIO_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "NOMBRE:";
            // 
            // BTN_UPDT_USUARIO
            // 
            this.BTN_UPDT_USUARIO.Location = new System.Drawing.Point(199, 234);
            this.BTN_UPDT_USUARIO.Name = "BTN_UPDT_USUARIO";
            this.BTN_UPDT_USUARIO.Size = new System.Drawing.Size(84, 41);
            this.BTN_UPDT_USUARIO.TabIndex = 13;
            this.BTN_UPDT_USUARIO.Text = "ACTUALIZAR";
            this.BTN_UPDT_USUARIO.UseVisualStyleBackColor = true;
            this.BTN_UPDT_USUARIO.Click += new System.EventHandler(this.BTN_UPDT_USUARIO_Click);
            // 
            // TXT_NOMBRE_USUARIO
            // 
            this.TXT_NOMBRE_USUARIO.Enabled = false;
            this.TXT_NOMBRE_USUARIO.Location = new System.Drawing.Point(107, 60);
            this.TXT_NOMBRE_USUARIO.Name = "TXT_NOMBRE_USUARIO";
            this.TXT_NOMBRE_USUARIO.Size = new System.Drawing.Size(176, 20);
            this.TXT_NOMBRE_USUARIO.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "CONTRASEÑA";
            // 
            // TXT_ID_USUARIO
            // 
            this.TXT_ID_USUARIO.Enabled = false;
            this.TXT_ID_USUARIO.Location = new System.Drawing.Point(107, 24);
            this.TXT_ID_USUARIO.Name = "TXT_ID_USUARIO";
            this.TXT_ID_USUARIO.Size = new System.Drawing.Size(100, 20);
            this.TXT_ID_USUARIO.TabIndex = 2;
            // 
            // TXT_CONTRA_USUARIO
            // 
            this.TXT_CONTRA_USUARIO.Enabled = false;
            this.TXT_CONTRA_USUARIO.Location = new System.Drawing.Point(107, 146);
            this.TXT_CONTRA_USUARIO.Name = "TXT_CONTRA_USUARIO";
            this.TXT_CONTRA_USUARIO.Size = new System.Drawing.Size(330, 20);
            this.TXT_CONTRA_USUARIO.TabIndex = 12;
            this.TXT_CONTRA_USUARIO.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "CONTRASEÑA";
            // 
            // BTN_INSERT_USUARIO
            // 
            this.BTN_INSERT_USUARIO.Location = new System.Drawing.Point(51, 234);
            this.BTN_INSERT_USUARIO.Name = "BTN_INSERT_USUARIO";
            this.BTN_INSERT_USUARIO.Size = new System.Drawing.Size(84, 41);
            this.BTN_INSERT_USUARIO.TabIndex = 4;
            this.BTN_INSERT_USUARIO.Text = "INSERT";
            this.BTN_INSERT_USUARIO.UseVisualStyleBackColor = true;
            this.BTN_INSERT_USUARIO.Click += new System.EventHandler(this.BTN_INSERT_USUARIO_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "NIVEL";
            // 
            // TXT_NIVEL_USUARIO
            // 
            this.TXT_NIVEL_USUARIO.Enabled = false;
            this.TXT_NIVEL_USUARIO.Location = new System.Drawing.Point(107, 194);
            this.TXT_NIVEL_USUARIO.Name = "TXT_NIVEL_USUARIO";
            this.TXT_NIVEL_USUARIO.Size = new System.Drawing.Size(330, 20);
            this.TXT_NIVEL_USUARIO.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "NIVEL";
            // 
            // BTN_CREAR_BASE
            // 
            this.BTN_CREAR_BASE.Location = new System.Drawing.Point(278, 373);
            this.BTN_CREAR_BASE.Name = "BTN_CREAR_BASE";
            this.BTN_CREAR_BASE.Size = new System.Drawing.Size(75, 23);
            this.BTN_CREAR_BASE.TabIndex = 5;
            this.BTN_CREAR_BASE.Text = "BASE";
            this.BTN_CREAR_BASE.UseVisualStyleBackColor = true;
            this.BTN_CREAR_BASE.Click += new System.EventHandler(this.BTN_CREAR_BASE_Click);
            // 
            // BTN_CREAR_TABLE
            // 
            this.BTN_CREAR_TABLE.Location = new System.Drawing.Point(419, 373);
            this.BTN_CREAR_TABLE.Name = "BTN_CREAR_TABLE";
            this.BTN_CREAR_TABLE.Size = new System.Drawing.Size(75, 23);
            this.BTN_CREAR_TABLE.TabIndex = 6;
            this.BTN_CREAR_TABLE.Text = "TABLA";
            this.BTN_CREAR_TABLE.UseVisualStyleBackColor = true;
            this.BTN_CREAR_TABLE.Click += new System.EventHandler(this.BTN_CREAR_TABLE_Click);
            // 
            // BTN_SEL_USUARIO
            // 
            this.BTN_SEL_USUARIO.Location = new System.Drawing.Point(151, 373);
            this.BTN_SEL_USUARIO.Name = "BTN_SEL_USUARIO";
            this.BTN_SEL_USUARIO.Size = new System.Drawing.Size(75, 23);
            this.BTN_SEL_USUARIO.TabIndex = 7;
            this.BTN_SEL_USUARIO.Text = "SELECT";
            this.BTN_SEL_USUARIO.UseVisualStyleBackColor = true;
            this.BTN_SEL_USUARIO.Click += new System.EventHandler(this.BTN_SEL_USUARIO_Click);
            // 
            // CMB_FILTRO_USUARIO
            // 
            this.CMB_FILTRO_USUARIO.FormattingEnabled = true;
            this.CMB_FILTRO_USUARIO.Location = new System.Drawing.Point(151, 30);
            this.CMB_FILTRO_USUARIO.Name = "CMB_FILTRO_USUARIO";
            this.CMB_FILTRO_USUARIO.Size = new System.Drawing.Size(138, 21);
            this.CMB_FILTRO_USUARIO.TabIndex = 17;
            // 
            // TXT_FILTRO_USUARIO
            // 
            this.TXT_FILTRO_USUARIO.Location = new System.Drawing.Point(313, 30);
            this.TXT_FILTRO_USUARIO.Name = "TXT_FILTRO_USUARIO";
            this.TXT_FILTRO_USUARIO.Size = new System.Drawing.Size(141, 20);
            this.TXT_FILTRO_USUARIO.TabIndex = 18;
            this.TXT_FILTRO_USUARIO.TextChanged += new System.EventHandler(this.TXT_FILTRO_USUARIO_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(208, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "FILTRO";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(355, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "VALOR";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(310, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // BTN_ABRIR_IMAGE
            // 
            this.BTN_ABRIR_IMAGE.Location = new System.Drawing.Point(464, 60);
            this.BTN_ABRIR_IMAGE.Name = "BTN_ABRIR_IMAGE";
            this.BTN_ABRIR_IMAGE.Size = new System.Drawing.Size(78, 26);
            this.BTN_ABRIR_IMAGE.TabIndex = 23;
            this.BTN_ABRIR_IMAGE.Text = "ABRIR";
            this.BTN_ABRIR_IMAGE.UseVisualStyleBackColor = true;
            this.BTN_ABRIR_IMAGE.Click += new System.EventHandler(this.button1_Click);
            // 
            // FRM_USUARIOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 395);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.TXT_FILTRO_USUARIO);
            this.Controls.Add(this.CMB_FILTRO_USUARIO);
            this.Controls.Add(this.TAB_PRINCIPAL);
            this.Controls.Add(this.BTN_SEL_USUARIO);
            this.Controls.Add(this.BTN_CREAR_BASE);
            this.Controls.Add(this.BTN_CREAR_TABLE);
            this.Name = "FRM_USUARIOS";
            this.Text = "USUARIOS";
            this.Load += new System.EventHandler(this.FRM_USUARIOS_Load);
            this.TAB_PRINCIPAL.ResumeLayout(false);
            this.tab_tbl_usuario.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DATA_GRID_USUARIOS)).EndInit();
            this.tab_tbl_us_detale.ResumeLayout(false);
            this.tab_tbl_us_detale.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl TAB_PRINCIPAL;
        private System.Windows.Forms.TabPage tab_tbl_usuario;
        private System.Windows.Forms.DataGridView DATA_GRID_USUARIOS;
        private System.Windows.Forms.TabPage tab_tbl_us_detale;
        private System.Windows.Forms.Button BTN_ACEPTAR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_NOMBRE_USUARIO;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTN_DEL_USUARIO;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BTN_UPDT_USUARIO;
        private System.Windows.Forms.TextBox TXT_NOMBRE_USUARIO;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TXT_ID_USUARIO;
        private System.Windows.Forms.TextBox TXT_CONTRA_USUARIO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BTN_INSERT_USUARIO;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXT_NIVEL_USUARIO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTN_CREAR_BASE;
        private System.Windows.Forms.Button BTN_CREAR_TABLE;
        private System.Windows.Forms.Button BTN_SEL_USUARIO;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TXT_AP_MATERNO_USUARIO;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TXT_AP_PATERMO_USUARIO;
        private System.Windows.Forms.ComboBox CMB_FILTRO_USUARIO;
        private System.Windows.Forms.TextBox TXT_FILTRO_USUARIO;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button BTN_ABRIR_IMAGE;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

